// index.js
const express = require('express');
const cors = require('cors');
const path = require('path');

const articleRoutes = require('./Routes/articleRoutes'); // lưu ở backend/routes/articleRoutes.js

const app = express();
const PORT = process.env.PORT || 5000;

// middleware
app.use(cors());
app.use(express.json()); // parse application/json
app.use(express.urlencoded({ extended: true }));

// API routes (tiền tố /api)
app.use('/api', articleRoutes);

// Serve frontend production build nếu cần
const frontendBuildPath = path.join(__dirname, '..', 'frontend', 'build');
app.use(express.static(frontendBuildPath));
app.get('*', (req, res) => {
    res.sendFile(path.join(frontendBuildPath, 'index.html'));
});

// error handler (đơn giản)
app.use((err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
