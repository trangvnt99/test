// backend/db.js
require('dotenv').config(); // nhớ npm install dotenv
const mysql = require('mysql2');

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '',
    database: process.env.DB_NAME || '', // <-- nếu trống, sẽ báo lỗi khi query
    port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
}).promise();

async function testConnection() {
    try {
        const [rows] = await pool.query('SELECT 1 + 1 AS result');
        console.log('✅ MySQL pool ok, test query result:', rows[0].result);
    } catch (err) {
        console.error('❌ MySQL connection error:', err.message);
        // không throw để server có thể vẫn khởi động (tuỳ bạn muốn)
    }
}

testConnection();

module.exports = pool;
