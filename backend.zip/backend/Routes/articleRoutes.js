
// Lấy tất cả bài viết
async function getAllArticles() {
    const [rows] = await pool.query('SELECT * FROM articles ORDER BY created_at DESC');
    return rows;
}

// Lấy bài viết theo ID
async function getArticleById(id) {
    const [rows] = await pool.query('SELECT * FROM articles WHERE id = ?', [id]);
    return rows[0];
}

// Thêm bài viết mới
async function addArticle(title, content, author) {
    const [result] = await pool.query(
        'INSERT INTO articles (title, content, author) VALUES (?, ?, ?)',
        [title, content, author]
    );
    return result.insertId;
}

// Cập nhật bài viết
async function updateArticle(id, title, content, author) {
    await pool.query(
        'UPDATE articles SET title = ?, content = ?, author = ? WHERE id = ?',
        [title, content, author, id]
    );
    return { message: '✅ Article updated successfully' };
}

// Xóa bài viết
async function deleteArticle(id) {
    await pool.query('DELETE FROM articles WHERE id = ?', [id]);
    return { message: '🗑️ Article deleted successfully' };
}

module.exports = {
    getAllArticles,
    getArticleById,
    addArticle,
    updateArticle,
    deleteArticle
};