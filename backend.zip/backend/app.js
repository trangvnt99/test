// app.js
const express = require('express');
const cors = require('cors');
const articleRoutes = require('./Routes/articleRoutes');

const app = express();
const path = require('path');

// Static file serving
app.use(express.static(path.join(__dirname, '../frontend/build')));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/build', 'index.html'));
});

app.use(cors());
app.use(express.json());  // Để parse JSON từ request body

// Sử dụng routes cho bài viết
app.use('/api', articleRoutes);

// Khởi động server
const PORT = process.env.PORT || 3000;
app.listen(PORT, (err) => {
    if (err) {
        console.error('Failed to start server:', err);
    } else {
        console.log(`Server is running on port ${PORT}`);
    }
});