// backend/controllers/articleController.js
const ArticleModel = require('../models/articleModel');

// GET list
exports.getArticles = async (req, res, next) => {
    try {
        const articles = await ArticleModel.getArticles();
        res.json(articles);
    } catch (err) {
        next(err);
    }
};

// GET by id
exports.getArticleById = async (req, res, next) => {
    try {
        const id = Number(req.params.id);
        if (!id) return res.status(400).json({ message: 'Invalid id' });

        const article = await ArticleModel.getArticleById(id);
        if (!article) return res.status(404).json({ message: 'Bài viết không tồn tại' });
        res.json(article);
    } catch (err) {
        next(err);
    }
};

// CREATE
exports.createArticle = async (req, res, next) => {
    try {
        const { title, content, image_url = null, category_id = null } = req.body;
        if (!title || !content) {
            return res.status(400).json({ message: 'title và content là bắt buộc' });
        }
        const result = await ArticleModel.createArticle({ title, content, image_url, category_id });
        res.status(201).json({ message: 'Created', articleId: result.insertId });
    } catch (err) {
        next(err);
    }
};

// UPDATE
exports.updateArticle = async (req, res, next) => {
    try {
        const id = Number(req.params.id);
        const { title, content, image_url = null, category_id = null } = req.body;
        if (!id) return res.status(400).json({ message: 'Invalid id' });

        const ok = await ArticleModel.updateArticle(id, { title, content, image_url, category_id });
        if (ok.affectedRows === 0) return res.status(404).json({ message: 'Bài viết không tồn tại' });
        res.json({ message: 'Updated' });
    } catch (err) {
        next(err);
    }
};

// DELETE
exports.deleteArticle = async (req, res, next) => {
    try {
        const id = Number(req.params.id);
        if (!id) return res.status(400).json({ message: 'Invalid id' });

        const ok = await ArticleModel.deleteArticle(id);
        if (ok.affectedRows === 0) return res.status(404).json({ message: 'Bài viết không tồn tại' });
        res.json({ message: 'Deleted' });
    } catch (err) {
        next(err);
    }
};
